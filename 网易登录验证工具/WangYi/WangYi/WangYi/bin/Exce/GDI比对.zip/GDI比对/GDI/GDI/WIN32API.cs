﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GDI
{
    //用于截图技术
    class WIN32API
    {

    }
}
